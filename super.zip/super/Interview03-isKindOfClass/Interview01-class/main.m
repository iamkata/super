//
//  main.m
//  Interview01-class
//
//  Created by MJ Lee on 2018/5/27.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJPerson.h"
#import <objc/runtime.h>

////左边的类对象是否是右边传进来的家伙
//- (BOOL)isMemberOfClass:(Class)cls {
//    return [self class] == cls;
//}
//
////左边的类对象或者类对象的父类是否是右边传进来的家伙
//- (BOOL)isKindOfClass:(Class)cls {
//    for (Class tcls = [self class]; tcls; tcls = tcls->superclass) {
//        if (tcls == cls) return YES;
//    }
//    return NO;
//}
//
////左边的元类对象是否是右边传进来的家伙
//+ (BOOL)isMemberOfClass:(Class)cls {
//    return object_getClass((id)self) == cls;
//}
//
////左边的元类对象或者元类对象的父类是否是右边传进来的家伙
//+ (BOOL)isKindOfClass:(Class)cls {
//    for (Class tcls = object_getClass((id)self); tcls; tcls = tcls->superclass) {
//        if (tcls == cls) return YES;
//    }
//    return NO;
//}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        //左边是实例对象，右边传类对象。左边是类对象右边传元类对象。
        
        id person = [[MJPerson alloc] init];
        
        NSLog(@"%d", [person isMemberOfClass:[MJPerson class]]);//1
        NSLog(@"%d", [person isMemberOfClass:[NSObject class]]);//0
        
        NSLog(@"%d", [person isKindOfClass:[MJPerson class]]);//1
        NSLog(@"%d", [person isKindOfClass:[NSObject class]]);//1
        
        
        NSLog(@"%d", [MJPerson isMemberOfClass:object_getClass([MJPerson class])]);//1
        NSLog(@"%d", [MJPerson isKindOfClass:object_getClass([NSObject class])]);//1
        
        //————————————————————————————————————————————————————————————————
        
        NSLog(@"%d", [NSObject isMemberOfClass:[NSObject class]]); // 0
        NSLog(@"%d", [MJPerson isMemberOfClass:[MJPerson class]]); // 0
        NSLog(@"%d", [MJPerson isKindOfClass:[MJPerson class]]); // 0
        
        // 这句代码的方法调用者不管是哪个类（只要是NSObject体系下的），都返回YES
        NSLog(@"%d", [NSObject isKindOfClass:[NSObject class]]); // 1
    }
    return 0;
}
