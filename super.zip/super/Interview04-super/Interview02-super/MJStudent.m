//
//  MJStudent.m
//  Interview02-super
//
//  Created by MJ Lee on 2018/5/27.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJStudent.h"

@implementation MJStudent

- (void)print
{
    [super print];
    
//objc_msgSendSuper(
//{
//    self,
//    [MJPerson class]
//}, sel_registerName("print"));
//
//int a = 10;
}

@end
